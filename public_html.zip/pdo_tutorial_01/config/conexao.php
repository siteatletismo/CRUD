<?php
// usado para conectar ao BD
$host = "localhost";
$db_name = "pdo_crud_01_bd_2info1";
$username = "aluno";
$password = "aluno";

try {
$con = new PDO("mysql:host={$host};dbname={$db_name}", $username,
$password);
}

catch(PDOException $exception){
echo "Connection error: " . $exception->getMessage();
}
?>